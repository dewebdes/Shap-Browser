﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Configuration;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using CefSharp;
using CefSharp.WinForms;
using FarsiLibrary.Win;
using Timer = System.Windows.Forms.Timer;
using System.Drawing;
using System.Reflection;
using mshtml;
using Newtonsoft.Json.Linq;

namespace SharpBrowser {

	/// <summary>
	/// The main SharpBrowser form, supporting multiple tabs.
	/// We used the x86 version of CefSharp V51, so the app works on 32-bit and 64-bit machines.
	/// If you would only like to support 64-bit machines, simply change the DLL references.
	/// </summary>
	internal partial class MainForm : Form {

		private string appPath = Path.GetDirectoryName(Application.ExecutablePath) + @"\";

		public static MainForm Instance;

		public static string Branding = "SharpBrowser";
		public static string UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.110 Safari/537.36";
		public static string HomepageURL = "https://www.google.com";
		public static string NewTabURL = "about:blank";
		public static string DownloadsURL = "sharpbrowser://storage/downloads.html";
		public static string FileNotFoundURL = "sharpbrowser://storage/errors/notFound.html";
		public static string CannotConnectURL = "sharpbrowser://storage/errors/cannotConnect.html";
		public static string SearchURL = "https://www.google.com/#q=";

		public bool WebSecurity = true;
		public bool CrossDomainSecurity = true;
		public bool WebGL = true;



		public MainForm() {

			Instance = this;

			InitializeComponent();

			InitBrowser();

			SetFormTitle(null);

		}

		private void MainForm_Load(object sender, EventArgs e) {

			InitAppIcon();
			InitTooltips(this.Controls);
			InitHotkeys();

            loadData();

            wb1.ScriptErrorsSuppressed = true;
            wb1.Navigate("https://mail.google.com/mail/u/0/h/end7493diirv/?zy=d&f=1");
            wb1.Visible = true;
            wb1.BringToFront();

           // wt.Enabled = true;
        }

		#region App Icon

		/// <summary>
		/// embedding the resource using the Visual Studio designer results in a blurry icon.
		/// the best way to get a non-blurry icon for Windows 7 apps.
		/// </summary>
		private void InitAppIcon() {
			assembly = Assembly.GetAssembly(typeof(MainForm));
			Icon = new Icon(GetResourceStream("sharpbrowser.ico"), new Size(64, 64));
		}
		
		public static Assembly assembly = null;
		public Stream GetResourceStream(string filename, bool withNamespace = true) {
			try {
				return assembly.GetManifestResourceStream("SharpBrowser.Resources." + filename);
			} catch (System.Exception ex) { }
			return null;
		}

		#endregion

		#region Tooltips & Hotkeys

		/// <summary>
		/// these hotkeys work when the user is focussed on the .NET form and its controls,
		/// AND when the user is focussed on the browser (CefSharp portion)
		/// </summary>
		private void InitHotkeys() {

			// browser hotkeys
			KeyboardHandler.AddHotKey(this, CloseActiveTab, Keys.W, true);
			KeyboardHandler.AddHotKey(this, CloseActiveTab, Keys.Escape, true);
			KeyboardHandler.AddHotKey(this, AddBlankWindow, Keys.N, true);
			KeyboardHandler.AddHotKey(this, AddBlankTab, Keys.T, true);
			KeyboardHandler.AddHotKey(this, RefreshActiveTab, Keys.F5);
			KeyboardHandler.AddHotKey(this, OpenDeveloperTools, Keys.F12);
			KeyboardHandler.AddHotKey(this, NextTab, Keys.Tab, true);
			KeyboardHandler.AddHotKey(this, PrevTab, Keys.Tab, true, true);

			// search hotkeys
			KeyboardHandler.AddHotKey(this, OpenSearch, Keys.F, true);
			KeyboardHandler.AddHotKey(this, CloseSearch, Keys.Escape);
			KeyboardHandler.AddHotKey(this, StopActiveTab, Keys.Escape);


		}

		/// <summary>
		/// we activate all the tooltips stored in the Tag property of the buttons
		/// </summary>
		public void InitTooltips(System.Windows.Forms.Control.ControlCollection parent) {
			foreach (Control ui in parent) {
				Button btn = ui as Button;
				if (btn != null) {
					if (btn.Tag != null) {
						ToolTip tip = new ToolTip();
						tip.ReshowDelay = tip.InitialDelay = 200;
						tip.ShowAlways = true;
						tip.SetToolTip(btn, btn.Tag.ToString());
					}
				}
				Panel panel = ui as Panel;
				if (panel != null) {
					InitTooltips(panel.Controls);
				}
			}
		}

		#endregion

		#region Web Browser & Tabs

		private FATabStripItem newStrip;
		private FATabStripItem downloadsStrip;

		private string currentFullURL;
		private string currentCleanURL;
		private string currentTitle;

		public HostHandler host;
		private DownloadHandler dHandler;
		private ContextMenuHandler mHandler;
		private LifeSpanHandler lHandler;
		private KeyboardHandler kHandler;
		private RequestHandler rHandler;

		/// <summary>
		/// this is done just once, to globally initialize CefSharp/CEF
		/// </summary>
		private void InitBrowser() {

			CefSettings settings = new CefSettings();

			settings.RegisterScheme(new CefCustomScheme {
				SchemeName = "sharpbrowser",
				SchemeHandlerFactory = new SchemeHandlerFactory()
			});

			settings.UserAgent = UserAgent;

			settings.IgnoreCertificateErrors = true;
			
			settings.CachePath = GetAppDir("Cache");

			Cef.Initialize(settings);

			dHandler = new DownloadHandler(this);
			lHandler = new LifeSpanHandler(this);
			mHandler = new ContextMenuHandler(this);
			kHandler = new KeyboardHandler(this);
			rHandler = new RequestHandler(this);

			InitDownloads();

			host = new HostHandler(this);

			AddNewBrowser(tabStrip1, HomepageURL);

		}

		/// <summary>
		/// this is done every time a new tab is openede
		/// </summary>
		private void ConfigureBrowser(ChromiumWebBrowser browser) {

			BrowserSettings config = new BrowserSettings();

			config.FileAccessFromFileUrls = (!CrossDomainSecurity).ToCefState();
			config.UniversalAccessFromFileUrls = (!CrossDomainSecurity).ToCefState();
			config.WebSecurity = WebSecurity.ToCefState();
			config.WebGl = WebGL.ToCefState();

			browser.BrowserSettings = config;

		}


		private static string GetAppDir(string name) {
			string winXPDir = @"C:\Documents and Settings\All Users\Application Data\";
			if (Directory.Exists(winXPDir)) {
				return winXPDir + Branding + @"\" + name + @"\";
			}
			return @"C:\ProgramData\" + Branding + @"\" + name + @"\";

		}

		private void LoadURL(string url) {
            url = pf.js_unscape(url);
			Uri outUri;
			string newUrl = url;
			string urlLower = url.Trim().ToLower();

			// UI
			SetTabTitle(CurBrowser, "Loading...");

			// load page
			if (urlLower == "localhost") {

				newUrl = "http://localhost/";

			} else if (url.CheckIfFilePath() || url.CheckIfFilePath2()) {

				newUrl = url.PathToURL();

			} else {

				Uri.TryCreate(url, UriKind.Absolute, out outUri);

				if (!(urlLower.StartsWith("http") || urlLower.StartsWith("sharpbrowser"))) {
					if (outUri == null || outUri.Scheme != Uri.UriSchemeFile) newUrl = "http://" + url;
				}

				if (urlLower.StartsWith("sharpbrowser:") ||

					// load URL if it seems valid
					(Uri.TryCreate(newUrl, UriKind.Absolute, out outUri)
					 && ((outUri.Scheme == Uri.UriSchemeHttp || outUri.Scheme == Uri.UriSchemeHttps) && newUrl.Contains(".") || outUri.Scheme == Uri.UriSchemeFile))) {

				} else {

					// run search if unknown URL
					newUrl = SearchURL + HttpUtility.UrlEncode(url);

				}

			}

			// load URL
			CurBrowser.Load(newUrl);

			// set URL in UI
			SetFormURL(newUrl);

			// always enable back btn
			EnableBackButton(true);
			EnableForwardButton(false);

		}

		private void SetFormTitle(string tabName) {


			if (tabName.CheckIfValid()) {

				this.Text = tabName + " - " + Branding;
				currentTitle = tabName;

			} else {

				this.Text = Branding;
				currentTitle = "New Tab";
			}

		}

		private void SetFormURL(string URL) {

			currentFullURL = URL;
			currentCleanURL = CleanURL(URL);

			TxtURL.Text = currentCleanURL;

			CurTab.CurURL = currentFullURL;

			CloseSearch();

		}

		private string CleanURL(string url) {
			if (url.BeginsWith("about:")) {
				return "";
			}
			url = url.RemovePrefix("http://");
			url = url.RemovePrefix("https://");
			url = url.RemovePrefix("file://");
			url = url.RemovePrefix("/");
			return url.DecodeURL();
		}
		private bool IsBlank(string url) {
			return (url == "" || url == "about:blank");
		}
		private bool IsBlankOrSystem(string url) {
			return (url == "" || url.BeginsWith("about:") || url.BeginsWith("chrome:") || url.BeginsWith("sharpbrowser:"));
		}

		public void AddBlankWindow() {

			// open a new instance of the browser

			ProcessStartInfo info = new ProcessStartInfo(Application.ExecutablePath, "");
			//info.WorkingDirectory = workingDir ?? exePath.GetPathDir(true);
			info.LoadUserProfile = true;

			info.UseShellExecute = false;
			info.RedirectStandardError = true;
			info.RedirectStandardOutput = true;
			info.RedirectStandardInput = true;

			Process.Start(info);
		}
		public void AddBlankTab() {
			AddNewBrowserTab("");
			this.InvokeOnParent(delegate() {
				TxtURL.Focus();
			});
		}

		public ChromiumWebBrowser AddNewBrowserTab(string url, bool focusNewTab = true, string refererUrl = null) {
			return (ChromiumWebBrowser)this.Invoke((Func<ChromiumWebBrowser>)delegate {

				// check if already exists
				foreach (FATabStripItem tab in TabPages.Items) {
					SharpTab tab2 = (SharpTab)tab.Tag;
					if (tab2 != null && (tab2.CurURL == url)) {
						TabPages.SelectedItem = tab;
						return tab2.Browser;
					}
				}

				FATabStripItem tabStrip = new FATabStripItem();
				tabStrip.Title = "New Tab";
				TabPages.Items.Insert(TabPages.Items.Count - 1, tabStrip);
				newStrip = tabStrip;

				SharpTab newTab = AddNewBrowser(newStrip, url);
				newTab.RefererURL = refererUrl;
				if (focusNewTab) timer1.Enabled = true;
				return newTab.Browser;
			});
		}
		private SharpTab AddNewBrowser(FATabStripItem tabStrip, String url) {
			if (url == "") url = NewTabURL;
			ChromiumWebBrowser browser = new ChromiumWebBrowser(url);

			// set config
			ConfigureBrowser(browser);

			// set layout
			browser.Dock = DockStyle.Fill;
			tabStrip.Controls.Add(browser);
			browser.BringToFront();

			// add events
			browser.StatusMessage += Browser_StatusMessage;
			browser.LoadingStateChanged += Browser_LoadingStateChanged;
			browser.TitleChanged += Browser_TitleChanged;
			browser.LoadError += Browser_LoadError;
			browser.AddressChanged += Browser_URLChanged;
			browser.DownloadHandler = dHandler;
			browser.MenuHandler = mHandler;
			browser.LifeSpanHandler = lHandler;
			browser.KeyboardHandler = kHandler;
			browser.RequestHandler = rHandler;

			// new tab obj
			SharpTab tab = new SharpTab {
				IsOpen = true,
				Browser = browser,
				Tab = tabStrip,
				OrigURL = url,
				CurURL = url,
				Title = "New Tab",
				DateCreated = DateTime.Now
			};

			// save tab obj in tabstrip
			tabStrip.Tag = tab;

			if (url.StartsWith("sharpbrowser:")) {
				browser.RegisterAsyncJsObject("host", host, true);
			}
			return tab;
		}

		public SharpTab GetTabByBrowser(IWebBrowser browser) {
			foreach (FATabStripItem tab2 in TabPages.Items) {
				SharpTab tab = (SharpTab)(tab2.Tag);
				if (tab != null && tab.Browser == browser) {
					return tab;
				}
			}
			return null;
		}

		public void RefreshActiveTab() {
			CurBrowser.Load(CurBrowser.Address);
		}

		public void CloseActiveTab() {
			if (CurTab != null/* && TabPages.Items.Count > 2*/) {

				// remove tab and save its index
				int index = TabPages.Items.IndexOf(TabPages.SelectedItem);
				TabPages.RemoveTab(TabPages.SelectedItem);

				// keep tab at same index focussed
				if ((TabPages.Items.Count - 1) > index) {
					TabPages.SelectedItem = TabPages.Items[index];
				}
			}
		}

		private void OnTabClosed(object sender, EventArgs e) {
			
		}

		private void OnTabClosing(FarsiLibrary.Win.TabStripItemClosingEventArgs e) {

			// exit if invalid tab
			if (CurTab == null){
				e.Cancel = true;
				return;
			}

			// add a blank tab if the very last tab is closed!
			if (TabPages.Items.Count <= 2) {
				AddBlankTab();
				//e.Cancel = true;
			}

		}

		private void StopActiveTab() {
			CurBrowser.Stop();
		}

		private bool IsOnFirstTab() {
			return TabPages.SelectedItem == TabPages.Items[0];
		}
		private bool IsOnLastTab() {
			return TabPages.SelectedItem == TabPages.Items[TabPages.Items.Count - 2];
		}

		private int CurIndex {
			get {
				return TabPages.Items.IndexOf(TabPages.SelectedItem);
			}
			set {
				TabPages.SelectedItem = TabPages.Items[value];
			}
		}
		private int LastIndex {
			get {
				return TabPages.Items.Count - 2;
			}
		}

		private void NextTab() {
			if (IsOnLastTab()) {
				CurIndex = 0;
			} else {
				CurIndex++;
			}
		}
		private void PrevTab() {
			if (IsOnFirstTab()) {
				CurIndex = LastIndex;
			} else {
				CurIndex--;
			}
		}

		public ChromiumWebBrowser CurBrowser {
			get {
				if (TabPages.SelectedItem != null && TabPages.SelectedItem.Tag != null) {
					return ((SharpTab)TabPages.SelectedItem.Tag).Browser;
				} else {
					return null;
				}
			}
		}

		public SharpTab CurTab {
			get {
				if (TabPages.SelectedItem != null && TabPages.SelectedItem.Tag != null) {
					return ((SharpTab)TabPages.SelectedItem.Tag);
				} else {
					return null;
				}
			}
		}

		public int CurTabLoadingDur {
			get {
				if (TabPages.SelectedItem != null && TabPages.SelectedItem.Tag != null) {
					int loadTime = (int)(DateTime.Now - CurTab.DateCreated).TotalMilliseconds;
					return loadTime;
				} else {
					return 0;
				}
			}
		}

		private void Browser_URLChanged(object sender, AddressChangedEventArgs e) {
			InvokeIfNeeded(() => {

				// if current tab
				if (sender == CurBrowser) {

					if (!Utils.IsFocussed(TxtURL)) {
						SetFormURL(e.Address);
					}

					EnableBackButton(CurBrowser.CanGoBack);
					EnableForwardButton(CurBrowser.CanGoForward);

					SetTabTitle((ChromiumWebBrowser)sender, "Loading...");

					BtnRefresh.Visible = false;
					BtnStop.Visible = true;

					CurTab.DateCreated = DateTime.Now;

				}

			});
		}

		private void Browser_LoadError(object sender, LoadErrorEventArgs e) {
			// ("Load Error:" + e.ErrorCode + ";" + e.ErrorText);
		}

		private void Browser_TitleChanged(object sender, TitleChangedEventArgs e) {
			InvokeIfNeeded(() => {

				ChromiumWebBrowser browser = (ChromiumWebBrowser)sender;

				SetTabTitle(browser, e.Title);

			});
		}

		private void SetTabTitle(ChromiumWebBrowser browser, string text) {

			text = text.Trim();
			if (IsBlank(text)) {
				text = "New Tab";
			}

			// save text
			browser.Tag = text;

			// get tab of given browser
			FATabStripItem tabStrip = (FATabStripItem)browser.Parent;
			tabStrip.Title = text;


			// if current tab
			if (browser == CurBrowser) {

				SetFormTitle(text);

			}
		}

		private void Browser_LoadingStateChanged(object sender, LoadingStateChangedEventArgs e) {
			if (sender == CurBrowser) {

				EnableBackButton(e.CanGoBack);
				EnableForwardButton(e.CanGoForward);

				if (e.IsLoading) {

					// set title
					//SetTabTitle();

				} else {

					// after loaded / stopped
					InvokeIfNeeded(() => {
						BtnRefresh.Visible = true;
						BtnStop.Visible = false;
					});
				}
			}
		}

		public void InvokeIfNeeded(Action action) {
			if (this.InvokeRequired) {
				this.BeginInvoke(action);
			} else {
				action.Invoke();
			}
		}

		private void Browser_StatusMessage(object sender, StatusMessageEventArgs e) {
		}

		public void WaitForBrowserToInitialize(ChromiumWebBrowser browser) {
			while (!browser.IsBrowserInitialized) {
				Thread.Sleep(100);
			}
		}

		private void EnableBackButton(bool canGoBack) {
			InvokeIfNeeded(() => BtnBack.Enabled = canGoBack);
		}
		private void EnableForwardButton(bool canGoForward) {
			InvokeIfNeeded(() => BtnForward.Enabled = canGoForward);
		}

		private void OnTabsChanged(TabStripItemChangedEventArgs e) {


			ChromiumWebBrowser browser = null;
			try {
				browser = ((ChromiumWebBrowser)e.Item.Controls[0]);
			} catch (System.Exception ex) { }


			if (e.ChangeType == FATabStripItemChangeTypes.SelectionChanged) {
				if (TabPages.SelectedItem == tabStripAdd) {
					AddBlankTab();
				} else {

					browser = CurBrowser;

					SetFormURL(browser.Address);
					SetFormTitle(browser.Tag.ConvertToString() ?? "New Tab");


					EnableBackButton(browser.CanGoBack);
					EnableForwardButton(browser.CanGoForward);

				}
			}

			if (e.ChangeType == FATabStripItemChangeTypes.Removed) {
				if (e.Item == downloadsStrip) downloadsStrip = null;
				if (browser != null) {
					browser.Dispose();
				}
			}

			if (e.ChangeType == FATabStripItemChangeTypes.Changed) {
				if (browser != null) {
					if (currentFullURL != "about:blank") {
						browser.Focus();
					}
				}
			}

		}

		private void timer1_Tick(object sender, EventArgs e) {
			TabPages.SelectedItem = newStrip;
			timer1.Enabled = false;
		}

		private void menuCloseTab_Click(object sender, EventArgs e) {
			CloseActiveTab();
		}

		private void menuCloseOtherTabs_Click(object sender, EventArgs e) {
			List<FATabStripItem> listToClose = new List<FATabStripItem>();
			foreach (FATabStripItem tab in TabPages.Items) {
				if (tab != tabStripAdd && tab != TabPages.SelectedItem) listToClose.Add(tab);
			}
			foreach (FATabStripItem tab in listToClose) {
				TabPages.RemoveTab(tab);
			}

		}

		public List<int> CancelRequests {
			get {
				return downloadCancelRequests;
			}
		}

		private void bBack_Click(object sender, EventArgs e) {
			CurBrowser.Back();
		}

		private void bForward_Click(object sender, EventArgs e) {
			CurBrowser.Forward();
		}

		private void txtUrl_TextChanged(object sender, EventArgs e) {

		}

		private void bDownloads_Click(object sender, EventArgs e) {
			AddNewBrowserTab(DownloadsURL);
		}

		private void bRefresh_Click(object sender, EventArgs e) {
			RefreshActiveTab();
		}

		private void bStop_Click(object sender, EventArgs e) {
			StopActiveTab();
		}
		private void TxtURL_KeyDown(object sender, KeyEventArgs e) {

			// if ENTER or CTRL+ENTER pressed
			if (e.IsHotkey(Keys.Enter) || e.IsHotkey(Keys.Enter, true)) {
				LoadURL(TxtURL.Text);

				// im handling this
				e.Handled = true;
				e.SuppressKeyPress = true;

				// defocus from url textbox
				this.Focus();
			}

			// if full URL copied
			if (e.IsHotkey(Keys.C, true) && Utils.IsFullySelected(TxtURL)) {

				// copy the real URL, not the pretty one
				Clipboard.SetText(CurBrowser.Address, TextDataFormat.UnicodeText);

				// im handling this
				e.Handled = true;
				e.SuppressKeyPress = true;
			}
		}

		private void txtUrl_Click(object sender, EventArgs e) {
			if (!Utils.HasSelection(TxtURL)) {
				TxtURL.SelectAll();
			}
		}

		private void OpenDeveloperTools() {
			CurBrowser.ShowDevTools();
		}

		private void tabPages_MouseClick(object sender, MouseEventArgs e) {
			/*if (e.Button == System.Windows.Forms.MouseButtons.Right) {
				tabPages.GetTabItemByPoint(this.mouse
			}*/
		}

		#endregion

		#region Download Queue

		private void MainForm_FormClosing(object sender, FormClosingEventArgs e) {

			// ask user if they are sure
			if (DownloadsInProgress()) {
				if (MessageBox.Show("Downloads are in progress. Cancel those and exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) {
					e.Cancel = true;
					return;
				}
			}

			// dispose all browsers
			try {
				foreach (TabPage tab in TabPages.Items) {
					ChromiumWebBrowser browser = (ChromiumWebBrowser)tab.Controls[0];
					browser.Dispose();
				}
			} catch (System.Exception ex) { }

		}

		public Dictionary<int, DownloadItem> downloads;
		public Dictionary<int, string> downloadNames;
		public List<int> downloadCancelRequests;

		/// <summary>
		/// we must store download metadata in a list, since CefSharp does not
		/// </summary>
		private void InitDownloads() {

			downloads = new Dictionary<int, DownloadItem>();
			downloadNames = new Dictionary<int, string>();
			downloadCancelRequests = new List<int>();

		}

		public Dictionary<int, DownloadItem> Downloads {
			get {
				return downloads;
			}
		}

		public void UpdateDownloadItem(DownloadItem item) {
			lock (downloads) {

				// SuggestedFileName comes full only in the first attempt so keep it somewhere
				if (item.SuggestedFileName != "") {
					downloadNames[item.Id] = item.SuggestedFileName;
				}

				// Set it back if it is empty
				if (item.SuggestedFileName == "" && downloadNames.ContainsKey(item.Id)) {
					item.SuggestedFileName = downloadNames[item.Id];
				}

				downloads[item.Id] = item;

				//UpdateSnipProgress();
			}
		}

		public string CalcDownloadPath(DownloadItem item) {

			string itemName = item.SuggestedFileName != null ? item.SuggestedFileName.GetAfterLast(".") + " file" : "downloads";

			string path = null;
			if (path != null) {
				return path;
			}

			return null;
		}

		public bool DownloadsInProgress() {
			foreach (DownloadItem item in downloads.Values) {
				if (item.IsInProgress) {
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// open a new tab with the downloads URL
		/// </summary>
		private void btnDownloads_Click(object sender, EventArgs e) {
			OpenDownloadsTab();
		}

		public void OpenDownloadsTab() {
			if (downloadsStrip != null && ((ChromiumWebBrowser)downloadsStrip.Controls[0]).Address == DownloadsURL) {
				TabPages.SelectedItem = downloadsStrip;
			} else {
				ChromiumWebBrowser brw = AddNewBrowserTab(DownloadsURL);
				downloadsStrip = (FATabStripItem)brw.Parent;
			}
		}

		#endregion

		#region Search Bar

		bool searchOpen = false;
		string lastSearch = "";

		private void OpenSearch() {
			if (!searchOpen) {
				searchOpen = true;
				InvokeIfNeeded(delegate() {
					PanelSearch.Visible = true;
					TxtSearch.Text = lastSearch;
					TxtSearch.Focus();
					TxtSearch.SelectAll();
				});
			} else {
				InvokeIfNeeded(delegate() {
					TxtSearch.Focus();
					TxtSearch.SelectAll();
				});
			}
		}
		private void CloseSearch() {
			if (searchOpen) {
				searchOpen = false;
				InvokeIfNeeded(delegate() {
					PanelSearch.Visible = false;
					CurBrowser.GetBrowser().StopFinding(true);
				});
			}
		}

		private void BtnClearSearch_Click(object sender, EventArgs e) {
			CloseSearch();
		}

		private void BtnPrevSearch_Click(object sender, EventArgs e) {
			FindTextOnPage(false);
		}
		private void BtnNextSearch_Click(object sender, EventArgs e) {
			FindTextOnPage(true);
		}

		private void FindTextOnPage(bool next = true) {
			bool first = lastSearch != TxtSearch.Text;
			lastSearch = TxtSearch.Text;
			if (lastSearch.CheckIfValid()) {
				CurBrowser.GetBrowser().Find(0, lastSearch, true, false, !first);
			} else {
				CurBrowser.GetBrowser().StopFinding(true);
			}
			TxtSearch.Focus();
		}

		private void TxtSearch_TextChanged(object sender, EventArgs e) {
			FindTextOnPage(true);
		}

		private void TxtSearch_KeyDown(object sender, KeyEventArgs e) {
			if (e.IsHotkey(Keys.Enter)) {
				FindTextOnPage(true);
			}
			if (e.IsHotkey(Keys.Enter, true) || e.IsHotkey(Keys.Enter, false, true)) {
				FindTextOnPage(false);
			}
		}



        #endregion

        private void tabStrip1_Changed(object sender, EventArgs e)
        {

        }
        void loadData()
        {
            actDL.Items.Add("دلتا - فایل لیست آگهی");
            actDL.Items.Add("دلتا - لیست آگهی");
            actDL.Items.Add("دلتا - آیتم آگهی");
            actDL.Items.Add("---------------");
            actDL.Items.Add("اینجاجاب");
            actDL.Items.Add("دیوار");
            actDL.Items.Add("Inject Telegram App 1");
            actDL.Items.Add("Run Divar Script 1");
            actDL.Items.Add("refreshMe");
            actDL.Items.Add("---------------");
            actDL.Items.Add("دریافت موبایل دیوار");
            actDL.Items.Add("---------------");
            actDL.Items.Add("سئو اتوماتیک");
            actDL.Items.Add("جی میل");
            actDL.Items.Add("همشهری");
            //actDL.Items.Add("Start Search Pages");
            actDL.Items.Add("---------------");
            actDL.Items.Add("Google SEO Finder");
            actDL.Items.Add("Start Search Pages");
            actDL.Items.Add("---------------");
            actDL.Items.Add("Open Telegram");
            //actDL.Items.Add("Inject Telegram App 1");
            actDL.Items.Add("Run Telegram App 1");
            actDL.Items.Add("Get New Numbers");
            //actDL.Items.Add("Get New Messages");

            actDL.Items.Add("---------------");
            actDL.Items.Add("Load Next URL");
            actDL.Items.Add("Inject Get Numbers App 1");
            //actDL.Items.Add("Inject Get Numbers App 2");
        }
        public string runmod = "";
        private void runbt_Click(object sender, EventArgs e)
        {
            var cmd = actDL.Text;
            switch (cmd)
            {
                case "دلتا - فایل لیست آگهی":
                    wb1.Visible = false;
                    delta3();
                    break;
                case "دلتا - لیست آگهی":
                    wb1.Visible = false;
                    delta();
                    break;
                case "دلتا - آیتم آگهی":
                    wb1.Visible = false;
                    delta2();
                    break;
                case "اینجاجاب":
                    jobinja();
                    break;
                case "دریافت موبایل دیوار":
                    act.Enabled = false;
                    wb1.Visible = false;
                    runmod = "divar2";
                    divarScript3();
                    break;
                case "Run Divar Script 1":
                    act.Enabled = false;
                    wb1.Visible = false;
                    runmod = "divar";
                    divarScript1();
                    break;
                case "refreshMe":
                    refreshMe();
                    break;
                case "دیوار":
                    act.Enabled = false;
                    runmod = "divar";
                    divar();

                    break;
                case "سئو اتوماتیک":
                    act.Enabled = false;
                    autoSEO();
                    break;
                case "جی میل":
                    openGmail();
                    break;
                case "همشهری":
                    Hamshahry();
                    break;
                case "Google SEO Finder":
                    Google_SEO_Finder();
                    break;
                case "Start Search Pages":
                    Start_Search_Pages();
                        break;
                case "Load Next URL":
                    Get_New_URLs();
                    break;
                case "Inject Get Numbers App 1":
                    GetNumbersFromUrl_Inject_1();
                    break;
                case "Inject Get Numbers App 2":
                    Inject_ShareCod_1();
                    break;
                case "Open Telegram":
                    //MessageBox.Show("open....");
                    LoadURL("https://web.telegram.org/#/im");
                    break;
                case "Inject Telegram App 1":
                    Telegram_Inject_1();
                    break;
                case "Run Telegram App 1":
                    Telegram_Run_1();
                    break;
                case "Get New Numbers":
                    Get_New_Numbers();
                    break;
               
            }
        }

        //-----------------
        public void divar()
        {
            wb1.Visible = false;
            LoadURL("https://divar.ir/");
            //afterDelayCmd = "Hamshahry_klik_estekhdam";
            //delayT.Interval = 16000;
            //delayT.Enabled = true;
        }
        public void divarScript0()
        {
            Telegram_Inject_1();
        }
        public void autoSEO()
        {
            wb1.Visible = false;
            LoadURL("http://maxim.shop/wp-login.php");
            //afterDelayCmd = "Hamshahry_klik_estekhdam";
            //delayT.Interval = 16000;
            //delayT.Enabled = true;
        }
        public void jobinja()
        {
            inremail = true;
            LoadURL("https://www.rahnama.com/");
            afterDelayCmd = "jobinja_klik_estekhdam";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public void delta()
        {
            //MessageBox.Show("1");
            inremail = true;
            LoadURL("https://www.delta.ir/");
            afterDelayCmd = "delta_load_nextlist";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public List<unknown> deltalist = new List<unknown>();
        public String deltalist_idx = "0";
        public void delta_load_nextlist()
        {
            //MessageBox.Show("2");
            //durl, lastvisit

            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            var query = "";
            query = "select * from wp_dlt_filelisturls where sid=62";// dieHrf=#sq#" + rt + "#sq#";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);
            var havAny = false;
            try
            {
                ////MessageBox.Show("1");
                var hcol = getUnknownList(qret);// Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                hcol = hcol.Where(a => a.props["durl"].Contains("تهران")).ToList();
                ////MessageBox.Show(hcol.Count().ToString());
                if (hcol.Count() > 0)
                {
                    havAny = true;
                    deltalist = hcol;
                }
                else
                {
                    havAny = false;
                }
            }
            catch
            {
                havAny = false;
            }

            deltalist = deltalist.OrderBy(a => a.id).ToList();
            var fd = deltalist.First().props["lastvisit"];
            if (String.IsNullOrWhiteSpace(fd) == true)
            {
                deltalist_idx = deltalist.First().id;
            }
            else
            {
                var tdh = deltalist.Where(a => String.IsNullOrWhiteSpace(a.props["lastvisit"]) == true);
                if (tdh.Any() == true)
                {
                    deltalist_idx = tdh.First().id;
                }
                else
                {
                    deltalist_idx = deltalist.OrderBy(a => a.props["lastvisit"]).First().id;
                }
            }

            if (havAny == false)
            {
                //RunQuery
                //nc = new Dictionary<string, string>();
                //nc.Add("cmd", "RunQuery");
                //query = "";
                //query = "insert into wp_adm_url (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
                //nc.Add("query", query);
                //qret = aph.sendForm(nc);
                delta_load_nextfile();
            }
            else
            {
                delta_start_next_list();
            }
        }
        public void delta_start_next_list()
        {
            //MessageBox.Show("3");
            ////MessageBox.Show("3");
            var tlr = deltalist.Where(a => a.id == deltalist_idx).First();
            var durl = tlr.props["durl"].Trim();
            LoadURL(durl);
            afterDelayCmd = "delta_parse_list";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public void delta_parse_list()
        {
            //MessageBox.Show("4");

            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://176.9.28.92/share/delta.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";

            //MessageBox.Show("41");
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;
                //MessageBox.Show("42");

                if (response.Success && response.Result != null)
                {
                    //MessageBox.Show("43");
                    
                }
            });

            
            if (true)
            {
                //r startDate = response.Result;
                afterDelayCmd = "delta_parse_list_2";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
        }
        public void delta_parse_file()
        {
            //MessageBox.Show("4");

            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://176.9.28.92/share/delta.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";

            //MessageBox.Show("41");
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;
                //MessageBox.Show("42");

                if (response.Success && response.Result != null)
                {
                    //MessageBox.Show("43");

                }
            });


            if (true)
            {
                //r startDate = response.Result;
                afterDelayCmd = "delta_read_file_data";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
        }
        public int scrollcont = 0;
        public void delte_save_list2()
        {
            //MessageBox.Show("5");
            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            var query = "";
            query = "update wp_dlt_filelisturls set lastvisit=#sq#T" + DateTime.Now.Ticks + "#sq# where id=" + deltalist_idx;// (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);

            delta_get_next_list_id();
            delta_start_next_list();
        }
        public void delte_save_list()
        {
            //MessageBox.Show("5");
            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            var query = "";
            query = "update wp_dlt_filelisturls set lastvisit=#sq#T" + DateTime.Now.Ticks + "#sq# where id=" + deltalist_idx;// (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);

            delta_get_next_list_id();
            delta_start_next_list();
        }
        int deltascroldcont = 0;
        public void delta_parse_list_2()
        {
            //MessageBox.Show("6");
            string script = string.Format("");

            script += "startfindcont();";
            //MessageBox.Show("61");
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;
                //MessageBox.Show("62");
                if (response.Success && response.Result != null)
                {
                    //MessageBox.Show("63");
                    deltascroldcont = Convert.ToInt32(response.Result.ToString());
                    

                }
            });


            if (true)
            {
                afterDelayCmd = "delta_check_scroll_cont";
                delayT.Interval = 6000;
                delayT.Enabled = true;
            }
        }
        public void delta_check_scroll_cont()
        {
            //MessageBox.Show(deltascroldcont.ToString());
            if (deltascroldcont == 0)
            {
                //MessageBox.Show("64");
                delte_save_list();
            }
            else
            {
                //MessageBox.Show("65");
                if (deltascroldcont > 24)
                {
                    //delte_save_list2();
                    //MessageBox.Show("66");
                    scrollcont = (deltascroldcont / 24);
                    //MessageBox.Show("scrollcont: " + scrollcont);
                    afterDelayCmd = "delta_scroll_next_page";
                    delayT.Interval = 6000;
                    delayT.Enabled = true;
                }
                else
                {
                    //MessageBox.Show("67");
                    delta_getFilePage();
                }
            }
        }
        public void delta_read_file_data()
        {
            string script = string.Format("");

            script += "readFileFields();";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var dres = (response.Result).ToString();
                    //scrollcont--;

                    var nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    var query = "";
                    query = "insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,0,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#"+DateTime.Now.ToString()+"#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,#sq#"+dres+"#sq#,#sq#"+lastfileurl+"#sq#,0,0,1,0,0)";
                    nc.Add("query", query);
                    var qret = aph.sendForm(nc);
                    //insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,0,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#12/5/2018 6:56:45 PM#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,#sq#props#sq#,#sq#maiurl#sq#,0,0,1,0,0)

                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    query = "update wp_dlt_fileurls set discheck=#sq#true#sq# where id=" + latestFileId;// (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
                    nc.Add("query", query);
                    qret = aph.sendForm(nc);


                }
            });


            afterDelayCmd = "delta_2";
            delayT.Interval = 60000;
            delayT.Enabled = true;

        }
        public void delta_scroll_next_page()
        {
            //MessageBox.Show("7");
            if (scrollcont > 0)
            {
                scrollcont--;
                string script = string.Format("");

                script += "scroll2next();";

                CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
                {
                    var response = x.Result;

                    if (response.Success && response.Result != null)
                    {
                        var dres = (response.Result);//.ToString());
                        scrollcont--;
                        
                    }
                });


                if (true)
                {
                    
                    afterDelayCmd = "delta_scroll_next_page";
                    delayT.Interval = 120000;
                    delayT.Enabled = true;
                    delta_getFilePage2();
                }
            }
            else
            {
                delta_getFilePage();
            }
        }
        public void delta_getFilePage2()
        {
            //MessageBox.Show("8");
            //insert into wp_dlt_fileurls (sid,ddate,listurl,discheck,durl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#12/5/2018 11:54:38 AM#sq#,123,#sq#false#sq#,#sq#durlt#sq#,0,0,1,0,0)
            //getfilelinksinlist
            string script = string.Format("");

            script += "getfilelinksinlist();";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var dres = (response.Result).ToString();
                    var har = pf.vbsplit(dres, "nnpp");

                    foreach (var h in har)
                    {
                        if (String.IsNullOrWhiteSpace(h) == true)
                        {
                            continue;
                        }
                        var nc = new Dictionary<string, string>();
                        nc.Add("cmd", "SelectTable");
                        var query = "";
                        query = "select * from wp_dlt_fileurls where durl=#sq#" + h + "#sq#";// dieHrf=#sq#" + rt + "#sq#";
                        nc.Add("query", query);
                        var qret = aph.sendForm(nc);
                        var havAny = false;
                        try
                        {
                            var hcol = getUnknownList(qret);
                            if (hcol.Count() > 0)
                            {
                                havAny = true;
                            }
                            else
                            {
                                havAny = false;
                            }
                        }
                        catch
                        {
                            havAny = false;
                        }

                        if (havAny == false)
                        {
                            nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            query = "";
                            query = "insert into wp_dlt_fileurls (sid,ddate,listurl,discheck,durl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" + DateTime.Now.ToString() + "#sq#," + deltalist_idx + ",#sq#false#sq#,#sq#" + h + "#sq#,0,0,1,0,0)";
                            nc.Add("query", query);
                            qret = aph.sendForm(nc);
                        }
                    }

                    //delte_save_list();
                    //afterDelayCmd = "delta_scroll_next_page";
                    //delayT.Interval = 16000;
                    //delayT.Enabled = true;
                }
            });

        }
        public void delta_getFilePage()
        {
            //MessageBox.Show("8");
            //insert into wp_dlt_fileurls (sid,ddate,listurl,discheck,durl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#12/5/2018 11:54:38 AM#sq#,123,#sq#false#sq#,#sq#durlt#sq#,0,0,1,0,0)
            //getfilelinksinlist
            string script = string.Format("");

            script += "getfilelinksinlist();";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var dres = (response.Result).ToString();
                    var har = pf.vbsplit(dres, "nnpp");

                    foreach(var h in har)
                    {
                        if (String.IsNullOrWhiteSpace(h) == true)
                        {
                            continue;
                        }
                        var nc = new Dictionary<string, string>();
                        nc.Add("cmd", "SelectTable");
                        var query = "";
                        query = "select * from wp_dlt_fileurls where durl=#sq#" + h + "#sq#";// dieHrf=#sq#" + rt + "#sq#";
                        nc.Add("query", query);
                        var qret = aph.sendForm(nc);
                        var havAny = false;
                        try
                        {
                            var hcol = getUnknownList(qret);
                            if (hcol.Count() > 0)
                            {
                                havAny = true;
                            }
                            else
                            {
                                havAny = false;
                            }
                        }
                        catch
                        {
                            havAny = false;
                        }

                        if (havAny == false)
                        {
                            nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            query = "";
                            query = "insert into wp_dlt_fileurls (sid,ddate,listurl,discheck,durl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" + DateTime.Now.ToString() + "#sq#," + deltalist_idx + ",#sq#false#sq#,#sq#" + h + "#sq#,0,0,1,0,0)";
                            nc.Add("query", query);
                            qret = aph.sendForm(nc);
                        }
                    }

                    delte_save_list();
                    //afterDelayCmd = "delta_scroll_next_page";
                    //delayT.Interval = 16000;
                    //delayT.Enabled = true;
                }
            });

        }
        public void delta_get_next_list_id()
        {
            //MessageBox.Show("9");
            try
            {
                //MessageBox.Show("A: " + deltalist_idx);
                deltalist_idx = deltalist.Where(a => Convert.ToInt64(a.id) > Convert.ToInt64(deltalist_idx)).First().id;
                //MessageBox.Show("B: " + deltalist_idx);
            }
            catch
            {
                delta_load_nextlist();
            }
        }
        public string latestFileId = "0";
        public string lastfileurl = "";
        public string datafile = @"C:\Users\Administrator\Desktop\list-1\citusage.js";

        public void delta_load_nextfile()
        {
            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            var query = "";
            query = "select * from wp_dlt_fileurls where (sid=62) and (discheck=#sq#false#sq#)";// dieHrf=#sq#" + rt + "#sq#";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);
            var havAny = false;
            try
            {
                ////MessageBox.Show("1");
                var hcol = getUnknownList(qret);// Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                ////MessageBox.Show(hcol.Count().ToString());
                if (hcol.Count() > 0)
                {
                    havAny = true;
                    latestFileId = hcol.First().id;
                    lastfileurl = hcol.First().props["durl"].Trim();
                    LoadURL(hcol.First().props["durl"].Trim());
                }
                else
                {
                    havAny = false;
                }
            }
            catch
            {
                havAny = false;
            }


            if (havAny == true)
            {
                afterDelayCmd = "delta_parse_file";// "delta_read_file_data";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
            else
            {
                delta();
            }
        }

        public void delta3()
        {
            inremail = true;
            LoadURL("https://www.delta.ir/");
            afterDelayCmd = "delta_load_datafile";
            delayT.Interval = 1600;
            delayT.Enabled = true;
        }

        public List<string> urlist = new List<string>();
        public int lastdatafilerowindx = -1;
        public void delta_load_datafile()
        {
            urlist = pf.vbsplit(System.IO.File.ReadAllText(datafile), Environment.NewLine).Reverse().ToList();
            delta_load_nextfile2();

        }
        public void delta_load_nextfile2()
        {
            //if (lastdatafilerowindx < 500000)
            //{
                lastdatafilerowindx++;

                try
                {
                    LoadURL(urlist[lastdatafilerowindx]);
                    afterDelayCmd = "delta_load_nextfile2";// "injectdeltajs";
                    //afterDelayCmd = "injectdeltajs";
                    delayT.Interval = (60000*2);
                    delayT.Enabled = true;
                }
                catch
                {
                    MessageBox.Show("fertig....");
                }
            //}
            //else
            //{
            //    MessageBox.Show("fertig.....");
            //}
        }


        public void injectdeltajs()
        {
            //MessageBox.Show("4");

            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://176.9.28.92/share/delta.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";

            //MessageBox.Show("41");
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;
                //MessageBox.Show("42");

                if (response.Success && response.Result != null)
                {
                    //MessageBox.Show("43");

                }
            });


            if (true)
            {
                //r startDate = response.Result;
                afterDelayCmd = "delta_load_nextfile3";
                delayT.Interval = 1000;
                delayT.Enabled = true;
            }
        }

        public void delta_load_nextfile3()
        {
            string script = string.Format("");

            script += "readFileFields();";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var dres = (response.Result).ToString();
                    //scrollcont--;
                    if (dres.Contains("ملک مورد نظر شما بدلیل حذف یا بایگانی در حال حاضر در سایت نمایش داده نمی شود") == false)
                    {
                        var nc = new Dictionary<string, string>();
                        nc.Add("cmd", "RunQuery");
                        var query = "";
                        query = "insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,0,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#" + DateTime.Now.ToString() + "#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq#ns#sq#,0,#sq#" + dres + "#sq#,#sq#"+ urlist[lastdatafilerowindx] + "#sq#,0,0,1,0,0)";
                        pf.SaveLog(query);
                        nc.Add("query", query);
                        var qret = aph.sendForm(nc);
                    }
                    else
                    {
                        lastdatafilerowindx--;
                    }
                    //MessageBox.Show(dres);
                    //insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,0,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#12/5/2018 6:56:45 PM#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,#sq#props#sq#,#sq#maiurl#sq#,0,0,1,0,0)

                    //nc = new Dictionary<string, string>();
                    //nc.Add("cmd", "RunQuery");
                    //query = "";
                    //query = "update wp_dlt_fileurls set discheck=#sq#true#sq# where id=" + latestFileId;// (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
                    //nc.Add("query", query);
                    //qret = aph.sendForm(nc);


                }
            });





            //LoadURL("https://www.delta.ir/");
            //afterDelayCmd = "
            delta_load_nextfile2();

            //delayT.Interval = 10000;
            //delayT.Enabled = true;
        }
        public void delta2()
        {
            inremail = true;
            LoadURL("https://www.delta.ir/");
            afterDelayCmd = "delta_load_nextfile";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public void Hamshahry()
        {
            inremail = true;
            LoadURL("https://www.rahnama.com/");
            afterDelayCmd = "Hamshahry_klik_estekhdam";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public string lastRID = "0";
        private async void divarScript3()
        {
            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            var query = "";
            query = "select * from wp_adm_url where (checkLevel=0) and (dieHrf like #sq#%/v/%#sq#) and (dieSource=#sq#" + "دیوار" + "#sq#)";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);
            var havAny = false;
            var tu = new unknown();
            try
            {
                var unL =getUnknownList(qret);
                var hcol = unL;// Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                if (hcol.Count() > 0)
                {
                    havAny = true;
                    tu = hcol.First();
                }
                else
                {
                    havAny = false;
                }
            }
            catch
            {
                havAny = false;
            }
            if (havAny == true)
            {
                var hrer = tu.props["dieHrf"];
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                lastRID = tu.id;
                query = "update wp_adm_url set checkLevel=1 where id=" + tu.id;// (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
                nc.Add("query", query);
                qret = aph.sendForm(nc);
                string script = string.Format("");
                script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
                script = "function refMedonx(){window.location.href='"+hrer+ "';}; refMedonx();";
                ////MessageBox.Show("getMobileNumbers");
                string returnValue = "";

                var task = CurBrowser.EvaluateScriptAsync(script);

                await task.ContinueWith(t =>
                {
                    if (!t.IsFaulted)
                    {
                        var response = t.Result;

                        if (response.Success && response.Result != null)
                        {
                            returnValue = response.Result.ToString();
                        }
                    }
                });

                afterDelayCmd = "divarScript0";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }

        }
        private async void divarScript4()
        {
            string script = string.Format("");
            script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function refMedonx2(){jQuery('#app > div > div > div.ui.container > div > div > div:nth-child(3) > div.right.floated.five.wide.computer.twelve.wide.tablet.column > div.ui.fluid.card.post-actions > div > div > button').click();}; refMedonx2();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            afterDelayCmd = "divarScript5";
            delayT.Interval = 16000;
            delayT.Enabled = true;

        }
        private async void divarScript5()
        {
            string script = string.Format("");
            script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function getMobNum(){var ret='';ret=jQuery('#app > div > div > div.ui.container > div > div > div:nth-child(3) > div.right.floated.five.wide.computer.twelve.wide.tablet.column > div.ui.fluid.card.post-fields > div > div:nth-child(1) > div:nth-child(1) > div > a').html(); return ret;}; getMobNum();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                        var nc = new Dictionary<string, string>();
                        nc.Add("cmd", "RunQuery");
                        var query = "";
                        //lastRID = tu.id;
                        query = "insert into wp_adm_url_data (sid,uid,dieMob,dieMail,dieXml,dieDate,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6," + lastRID + ",#sq#" + returnValue + "#sq#,#sq#ns#sq#,#sq#xml#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,0,0,1,0,0)";
                        nc.Add("query", query);
                        var qret = aph.sendForm(nc);
                    }
                }
            });

            afterDelayCmd = "divarScript3";
            delayT.Interval = 16000;
            delayT.Enabled = true;

        }
        private async void divarScript1()
        {
            string script = string.Format("");
            script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function hklik1(){jQuery('a#app > div > div > div:nth-child(4) > div > div > div > div.nine.wide.computer.ten.large.screen.twelve.tablet.widescreen.column > div:nth-child(3) > div > div:nth-child(1) > a').click();};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
                                                                                                                                                                                                                                                        //https://divar.ir/v/%DB%B1%DB%B5%DB%B0%DB%B0%D9%85%D8%AA%D8%B1-%DA%A9%D9%84%D9%86%DA%AF%DB%8C-%D9%81%D8%B1%D8%B4%D8%AA%D9%87_%D8%B2%D9%85%DB%8C%D9%86-%D9%88-%DA%A9%D9%84%D9%86%DA%AF%DB%8C_%D8%AA%D9%87%D8%B1%D8%A7%D9%86_%D8%A7%D9%84%D9%87%DB%8C%D9%87_%D8%AF%DB%8C%D9%88%D8%A7%D8%B1/_OUE_52vp
                                                                                                                                                                                                                                                        ////MessageBox.Show("getMobileNumbers");
            script = "function hklik1(){var acol=jQuery('a');var ret='';for(var i=0;i<=acol.length-1;i++){ret+=(jQuery(acol[i]).attr('href'))+'hhreref'};return ret;}; hklik1();";
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                        var retar = pf.vbsplit(returnValue, "hhreref");
                        foreach(var rt in retar)
                        {
                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "SelectTable");
                            var query = "";
                            query = "select * from wp_adm_url where dieHrf=#sq#" + rt + "#sq#";
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);
                            var havAny = false;
                            try
                            {
                                var hcol = Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                                if (hcol.Count() > 0)
                                {
                                    havAny = true;
                                }
                                else
                                {
                                    havAny = false;
                                }
                            }
                            catch
                            {
                                havAny = false;
                            }

                            if (havAny == false)
                            {
                                //RunQuery
                                nc = new Dictionary<string, string>();
                                nc.Add("cmd", "RunQuery");
                                query = "";
                                query = "insert into wp_adm_url (sid,dieSource,dieHrf,checkLevel,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#دیوار#sq#,#sq#https://divar.ir" + rt + "#sq#,0,0,0,1,0,0)";// "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + rt + "#sq#";
                                nc.Add("query", query);
                                qret = aph.sendForm(nc);
                            }
                        }
                        ////MessageBox.Show(returnValue);

                    //------------------------------------------

                    //-----------------------------------------
                    }
                }
            });

            afterDelayCmd = "refreshMe";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        private async void refreshMe()
        {
            string script = string.Format("");
            script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function refMedon(){window.location.href=window.location.href}; refMedon();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            afterDelayCmd = "divarScript0";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        private async void Hamshahry_klik_estekhdam()
        {
            string script = string.Format("");
            script = "function hklik1(){window.location.href=jQuery('#listings > div:nth-child(8) > div > div > div.tboxm-red > a').attr('href');};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function hklik1(){var lst='استخدام';var lnk1=jQuery('a:contains('+lst+')').attr('href');window.location.href=lnk1;};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            afterDelayCmd = "Hamshahry_klik_estekhdam_programer_1";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        private async void Hamshahry_klik_estekhdam_programer_1()
        {
            string script = string.Format("");
            script = "jQuery(\"a:contains('استخدام برنامه نویس')\").click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function hklik1(){var lst='برنامه نویس';var lnk1=jQuery('a:contains('+lst+')').attr('href');window.location.href=lnk1;};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            afterDelayCmd = "Hamshahry_klik_estekhdam_programer_2";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        private async void Hamshahry_klik_estekhdam_programer_2()
        {
            string script = string.Format("");
            script = "jQuery(\"a:contains('برنامه نویس')\").click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            script = "function hklik1(){var lst='برنامه نویس';var lnk1=jQuery(jQuery('.uk-grid-small a')[0]).attr('href');window.location.href=lnk1;};hklik1();";// "var lst='استخدام';jQuery('a:contains('+lst+')').click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            afterDelayCmd = "Hamshahry_klik_estekhdam_programer_3";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        public List<string> emailsCol = new List<string>();
        private async void Hamshahry_klik_estekhdam_programer_3()
        {
            ////MessageBox.Show("heir");
            string script = string.Format("");
            script = "jQuery(a:contains('استخدام')).click();";// "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";

            script = "function getLinks1() { var acol1 = jQuery('a'); for (var i = 0; i <= acol1.length - 1; i++) { if (jQuery(acol1[i]).attr('href') == undefined) { continue; }; if (jQuery(acol1[i]).attr('href').indexOf('fav/insert/aid') > -1) { var ar2 = jQuery(acol1[i]).attr('href').split('/'); var mid = ar2[ar2.length - 2]; try{telshow(mid);}catch(err) {}; for (var j = 0; j <= 1000; j++) { var a1 = i * j; }; }; }; var ret = ''; var col2 = jQuery('.uk-first-column'); for (var j = 0; j <= col2.length - 1; j++) { var el1 = jQuery(col2[j]).text(); ret += el1 + 'nnpp'; }; return ret; }; getLinks1();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            ////MessageBox.Show("res: " + returnValue);

            var elist = new List<string>();
            var emar = pf.vbsplit(returnValue, "nnpp");
            foreach(var e in emar)
            {
                var spar1 = pf.vbsplit(e, " ");
                foreach(var p in spar1)
                {
                    if (p.Contains("@"))
                    {
                        elist.Add(cleanMail(p.Trim()));
                    }
                }
                //if (e.Contains("@") && e.Contains("."))
                //{
                //    var ret = clean_text_singleChar(e.Trim(), "@");
                //    elist.Add(ret);
                //}
            }

            var mstr = "";
            foreach(var m in elist)
            {
                // //MessageBox.Show(m);
                mstr += m + Environment.NewLine;
            }
            ////MessageBox.Show("final: " + mstr);
            System.IO.File.WriteAllText(Application.StartupPath + "\\" + "Mails\\" + DateTime.Now.Ticks + ".txt", mstr);
            //using (StreamWriter sw = File.AppendText(Application.StartupPath + "\\" + "MailLog.txt"))
            //{
            //    sw.WriteLine(DateTime.Now.ToString() + " - " + to_txt);

            //}
            emailsCol = elist;

            //afterDelayCmd = "Hamshahry_klik_estekhdam_programer_3";
            //delayT.Interval = 16000;
            //delayT.Enabled = true;




            openGmail();
        }
        public string cleanMail(string ts)
        {
            var alpha = "1234567890qwertyuiopasdfghjklzxcvbnm.@_-";
            var ret = "";
            ts = ts.ToLower();
            foreach(var c in ts)
            {
                if (alpha.Contains(c.ToString()))
                {
                    ret += c.ToString();
                }
            }
            return ret;
        }

        public int mindx = 0;
        void openGmail()
        {
            mindx = -1;
            LoadURL("https://mail.google.com/mail/u/0/h/end7493diirv/?zy=d&f=1");
            afterDelayCmd = "getnextMail";
            delayT.Interval = 16000;
            delayT.Enabled = true;
        }
        void getnextMail()
        {

           // //MessageBox.Show("get next mail " + (mindx < emailsCol.Count() - 1));
            if (mindx < emailsCol.Count() - 1)
            {
                mindx++;
             //   //MessageBox.Show(emailsCol[mindx]);
                LoadURL("https://mail.google.com/mail/u/0/h/end7493diirv/?zy=d&f=1");
                wb1.ScriptErrorsSuppressed = true;
                wb1.Navigate("https://mail.google.com/mail/u/0/h/end7493diirv/?zy=d&f=1");
                wt.Enabled = true;
            }
            else
            {
                ////MessageBox.Show("send gmail finish....");
                act.Enabled = true;
            }

        }
        string nextcmd = "goto_compose";
        private void wt_Tick(object sender, EventArgs e)
        {
            wt.Enabled = false;
            inject_js(nextcmd);
        }
        void inject_js(string cmd)
        {
           // //MessageBox.Show("inject 1");
            string script = string.Format("");
            var sctx = pf.netrouter("http://176.9.28.92/share/GMail1.js");
            var diePM = pf.netrouter("http://176.9.28.92/share/resum.txt");
            var logHtm = pf.netrouter("http://176.9.28.92/share/url-mobile-Log.html");
            sctx = sctx.Replace("{Log.html}", logHtm);


            sctx = sctx.Replace(Environment.NewLine, "");

            var subj = "رزومه کاوه عینی";
            var subject_txt = pf.js_scape(subj);
            var to_txt = pf.js_scape(emailsCol[mindx]);

            sctx = sctx.Replace("[to_txt]", to_txt);
            sctx = sctx.Replace("[subject_txt]", subject_txt);
            sctx = sctx.Replace("[pm_txt]", pf.js_scape(diePM));

            HtmlElement head = wb1.Document.GetElementsByTagName("head")[0];
           

            HtmlElement scriptEl2 = wb1.Document.CreateElement("script");
            IHTMLScriptElement element2 = (IHTMLScriptElement)scriptEl2.DomElement;
            element2.text = sctx;
            head.AppendChild(scriptEl2);

            //script = sctx;
            //CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            //{
            //    var response = x.Result;

            //    if (response.Success && response.Result != null)
            //    {

            //        var res = response.Result;
            //    }
            //});
            


            nextcmd = "";
            var next_wait = 0;

         //   //MessageBox.Show("inject 2: " + cmd);
            switch (cmd)
            {
                case "goto_compose":
                    //LoadURL("https://mail.google.com/mail/u/0/h/end7493diirv/?&cs=b&pv=tl&v=b");
                    wb1.Navigate("https://mail.google.com/mail/u/0/h/end7493diirv/?&cs=b&pv=tl&v=b");
                    nextcmd = "fill_send";
                    next_wait = 10000;
                    break;

              
                case "fill_send":
                    wb1.Document.InvokeScript("fill_send");
                    //script = "fill_send();";
                    //CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
                    //{
                    //    var response = x.Result;

                    //    if (response.Success && response.Result != null)
                    //    {

                    //        var res = response.Result;
                    //    }
                    //});
                    ////wb1.Document.InvokeScript("fill_send");
                    //nextcmd = "stop0";
                    //next_wait = 0;
                    

                    break;
            }


            if (nextcmd != "stop")
            {
                if (next_wait > 0)
                {
                    wt.Interval = next_wait;
                    wt.Enabled = true;
                }
                else
                {
                    nextcmd = "goto_compose";
                    //pf.GetRandomNumber(16000, 240000);
                    //getnext();
                    callxt();
                }
            }

        }
        private void xt_Tick(object sender, EventArgs e)
        {
            xt.Enabled = false;
            getnextMail();
        }
        void callxt()
        {
            xt.Interval = pf.GetRandomNumber(16000, 240000);
            xt.Enabled = true;
        }

        string clean_text_singleChar(string ts, string chr)
        {
            var ret = "";

            var tp = pf.vbsplit(ts, "\n");
            for (var k = 0; k <= tp.Length - 1; k++)
            {
                if (tp[k].Contains(chr))
                {
                    ts = tp[k];
                    break;
                }
            }

            tp = pf.vbsplit(ts, "\t");
            for (var k = 0; k <= tp.Length - 1; k++)
            {
                if (tp[k].Contains(chr))
                {
                    ts = tp[k];
                    break;
                }
            }

            tp = pf.vbsplit(ts, "\r");
            for (var k = 0; k <= tp.Length - 1; k++)
            {
                if (tp[k].Contains(chr))
                {
                    ts = tp[k];
                    break;
                }
            }

            tp = pf.vbsplit(ts, "/");
            for (var k = 0; k <= tp.Length - 1; k++)
            {
                if (tp[k].Contains(chr))
                {
                    ts = tp[k];
                    break;
                }
            }

            tp = pf.vbsplit(ts, @"\");
            for (var k = 0; k <= tp.Length - 1; k++)
            {
                if (tp[k].Contains(chr))
                {
                    ts = tp[k];
                    break;
                }
            }

            ret = ts;

            return ret;
        }
        bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        //----------------

        public void Google_SEO_Finder()
        {
            LoadURL("https://google.com");
        }
        public void Start_Search_Pages()
        {
            Inject_ShareCod_google();
            return;
            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://code.jquery.com/jquery-1.11.0.min.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";
            //MessageBox.Show("1");
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                    //MessageBox.Show("2");
                    //startDate is the value of a HTML element.
                }
            });
            //MessageBox.Show("3");
            ////MessageBox.Show("OK");
            afterDelayCmd = "Inject_ShareCod_google";
            delayT.Interval = 10000;
            delayT.Enabled = true;
        }
        public void Inject_ShareCod_google()
        {
            jsCmdT.Enabled = false;
            google_search_1();
            return;
            ////MessageBox.Show("4");
            string script = string.Format("");
            var sctx = pf.netrouter("http://176.9.28.92/share/GoogleSearch.js");// telegram.js");
            //var logHtm = pf.netrouter("http://176.9.28.92/share/SEOLog.html");
            //sctx = sctx.Replace("{Log.html}", logHtm);
            //https://176.9.28.92/share/delta.js

            sctx = sctx.Replace(Environment.NewLine, "");

            script = sctx;
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    ////MessageBox.Show("5");
                    var res = response.Result;
                }
            });
            ////MessageBox.Show("6");
            jsCmdT.Enabled = true;

            if (true)
            {
                afterDelayCmd = "google_search_1";
                delayT.Interval = 6000;
                delayT.Enabled = true;
            }
        }
        private async void google_search_1()
        {
            var sitename = System.Configuration.ConfigurationSettings.AppSettings["sitename"];
            var interval = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["interval"]);

            // //MessageBox.Show("7");
            string script = string.Format("");
            script = "function google_search_1() { var allel = document.all; var found = false; for (var i = 0; i <= allel.length - 1; i++) { try { if (allel[i].innerText.toLocaleLowerCase().indexOf('" + sitename + "') > -1) { alert('find this...'); found = true; break; } } catch (w) { } } if (found == false) { document.getElementById('pnnext').click(); return 'false'; } return 'true'; }; google_search_1();";
            ////MessageBox.Show("getMobileNumbers");
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

           // //MessageBox.Show(returnValue);


            // //MessageBox.Show("0000");
            //google_search_1();
            // Inject_ShareCod_google();
            if (returnValue == "false")
            {
                afterDelayCmd = "Inject_ShareCod_google";
                delayT.Interval = interval;// 10000;
                delayT.Enabled = true;
            }
            //script = "google_search_1();";
            //CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            //{
            //    var response = x.Result;

            //    if (response.Success && response.Result != null)
            //    {
            //        ////MessageBox.Show("8");
            //        var res = response.Result;
            //    }
            //});
        }

        //-------------------------------- URLs -------------------------------------
        public class url
        {
            public string id = "";
            public string dieUrl = "";
            public string dieSource = "";
            public string dieChecked = "";
            public string dieDate = "";
            public url() { }
        }
        public List<url> urList = new List<url>();
        public int lastUrlIndx = -1;
        void Get_New_URLs()
        {
            var jsn = pf.netrouter("http://panel.maxim.shop/root/admin/get_next_url_for_mbile.aspx");
            if (jsn != "null")
            {
                urList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<url>>(jsn);
                lastUrlIndx = -1;

                loadNextUrl();
            }
            else
            {
                urList = null;
                //MessageBox.Show("Fertig : No New URL Found...");
            }
        }
        void loadNextUrl()
        {
            lastUrlIndx++;
            if (lastUrlIndx <= (urList.Count() - 1))
            {
                LoadURL(pf.js_unscape(urList[lastUrlIndx].dieUrl));

                //if(autoGetNumbers==)
                //GetNumbersFromUrl_Inject_1
                afterDelayCmd = "GetNumbersFromUrl_Inject_1";
                delayT.Interval = 10000;
                delayT.Enabled = true;
            }
            else
            {
                //MessageBox.Show("Fertif: URL List Ended....");
            }
        }
        void GetNumbersFromUrl_Inject_1()
        {

            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://code.jquery.com/jquery-1.11.0.min.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                    //startDate is the value of a HTML element.
                }
            });

            //MessageBox.Show("OK");
            afterDelayCmd = "Inject_ShareCod_1";
            delayT.Interval = 10000;
            delayT.Enabled = true;
        }
        public string autoGetNumbers = "no";
        void Inject_ShareCod_1()
        {
            string script = string.Format("");
            var sctx = pf.netrouter("http://176.9.28.92/share/telegram.js");
            var logHtm = pf.netrouter("http://176.9.28.92/share/url-mobile-Log.html");
            sctx = sctx.Replace("{Log.html}", logHtm);


            sctx = sctx.Replace(Environment.NewLine, "");
            
            script = sctx;
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    
                    var res = response.Result;
                }
            });

            jsCmdT.Enabled = true;

            if (autoGetNumbers == "yes")
            {
                afterDelayCmd = "getLinksAndMobiles";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
            //MessageBox.Show("inject share 1");
        }
        public void getLinksAndMobiles()
        {
            string script = string.Format("");

            //MessageBox.Show("getMobileNumbers");

            script = "getChildLinks();";
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {

                    var res = response.Result;
                }
            });

            afterDelayCmd = "getMobileNumbers";
            delayT.Interval = (16000*3);
            delayT.Enabled = true;

        }
        public void getMobileNumbers()
        {
            string script = string.Format("");

            //MessageBox.Show("getMobileNumbers");

            script = "getMobileNumbers();";
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {

                    var res = response.Result;
                }
            });
        }
        //------------------------------------------------------------------------

        public class mob
        {
            public string id = "";
            public string dieNumber = "";
            public string haveTelegram = "";
            public string doTest = "";
            public string dieName = "";
            public string dieSource = "";

            public mob() { }
        }
        public List<mob> newNumbers = new List<mob>();
        public BST_PublicHelper.PubFuncs pf = new BST_PublicHelper.PubFuncs();
        public string dt = "";

        void Get_New_Numbers()
        {
            var jsn = pf.netrouter("http://panel.maxim.shop/root/admin/get_next_mobile_forTest.aspx");
            if (jsn != "null")
            {
                newNumbers = Newtonsoft.Json.JsonConvert.DeserializeObject<List<mob>>(jsn);
                //MessageBox.Show(newNumbers[0].dieNumber);
                //var ncx = new mob();
                //ncx.dieNumber = "12345678";
                //newNumbers.Insert(0, ncx);
                //jsn = Newtonsoft.Json.JsonConvert.SerializeObject(newNumbers);

                //create new list structure of numbers....
                dt = jsn;
                start_check_new_numbers();
            }
            else
            {
                newNumbers = null;
                MessageBox.Show("Fertig : No New Number Found...");
            }
        }
        
        void start_check_new_numbers()
        {
            string script = string.Format("");

            script += "var dt=" + dt + ";start_check_new_numbers();";
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                }
            });

            //MessageBox.Show("OK");
        }
        void Telegram_Inject_1()
        {

            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://code.jquery.com/jquery-1.11.0.min.js';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('head')[0].appendChild(script);";
            
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                    //startDate is the value of a HTML element.
                }
            });

            //MessageBox.Show("OK");
            injectSendKey();
        }
        void injectSendKey()
        {
            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://www.dropbox.com/s/svxpdc1c5t218ui/jquery.sendkeys.js?raw=1';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('body')[0].appendChild(script);";
           
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                    //startDate is the value of a HTML element.
                }
            });

            //MessageBox.Show("OK-2");
            injectbililiteRange();
        }
        void injectbililiteRange()
        {
            string script = string.Format("");

            script += "var script = document.createElement('script');";
            script += "script.src = 'https://www.dropbox.com/s/eudnm8ru9dsukqj/bililiteRange.js?raw=1';";
            script += "script.type = 'text/javascript';";
            script += "document.getElementsByTagName('body')[0].appendChild(script);";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                    //startDate is the value of a HTML element.
                }
            });

            //MessageBox.Show("OK-3");
            if (runmod == "divar")
            {
                //divarScript1();
                afterDelayCmd = "divarScript1";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
            if (runmod == "divar2")
            {
                //divarScript1();
                afterDelayCmd = "divarScript4";
                delayT.Interval = 16000;
                delayT.Enabled = true;
            }
        }

        void Telegram_Run_1()
        {
            string script = string.Format("");
            //var pf = new BST_PublicHelper.PubFuncs();
            var sctx = pf.netrouter("http://176.9.28.92/share/telegram.js");
            var logHtm = pf.netrouter("http://176.9.28.92/share/Log.html");
            sctx = sctx.Replace("{Log.html}", logHtm);


            //  var jqHtm = "";// pf.netrouter("http://176.9.28.92/share/jq.js");
            //  sctx = sctx.Replace("{ jquery }", jqHtm);
            //  var sendKeyHtm = pf.netrouter("http://176.9.28.92/share/keyprs/jquery.sendkeys.js");
            //  sctx = sctx.Replace("{ sendkey }", sendKeyHtm);
            //  var bililitHtm = pf.netrouter("http://176.9.28.92/share/keyprs/bililiteRange.js");
            //  sctx = sctx.Replace("{ bililit }", bililitHtm);


              sctx = sctx.Replace(Environment.NewLine, "");
            //  //MessageBox.Show(sctx);

            //  // script += "function fnc1(){var tx0 = jQuery(jQuery('.im_dialog_message_wrap')[1]).text();return tx0;}";
            ////  script = sctx;// "alert(123);mxStart();";



            //  string script = string.Format("");

            //  script += "var script = document.createElement('script');";
            //  script += "script.type = 'text/javascript';var scrpdata='"+sctx+"';";
            //  script += "try {script.appendChild(document.createTextNode(scrpdata));} catch(e) {script.text = data;};alert(123);";

            //  script += "document.getElementsByTagName('head')[0].appendChild(script);";

            //  // MessageBox.Show(CurBrowser.GetMainFrame().tex.GetText());

            //  //MessageBox.Show(script);
            script = sctx;
            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    //MessageBox.Show("123");
                    //jsCmdT.Enabled = true;
                    var res = response.Result;
                    // MessageBox.Show(res.ToString());
                }
            });

            jsCmdT.Enabled = true;
        }
        public class cmd
        {
            public cmd(string n,string v){
                this.name = n;
                this.val = v;
            }
            public string name = "";
            public string val = "";
        }
        public List<cmd> cmdL = new List<cmd>();
        MaximConnectore.Basic aph = new MaximConnectore.Basic();
        string sid = "6";//admin

        public class msg
        {
            public string id = "";
            public string dieTitle = "";
            public string dieText = "";
            public string dieType = "";

            public msg() { }
        }
        public msg dieMsg = new msg();

        void Get_Messages_Data(string id)
        {
            var jsn = pf.netrouter("http://panel.maxim.shop/root/admin/get_next_pm_forMobile.aspx?id=" + id);
            if (jsn != "null")
            {
                dieMsg = Newtonsoft.Json.JsonConvert.DeserializeObject<msg>(jsn);

                var jsn2 = pf.netrouter("http://panel.maxim.shop/root/admin/get_mobiles_for_pm.aspx?id=" + id);
                if (jsn2 != "null")
                {
                    newNumbers = Newtonsoft.Json.JsonConvert.DeserializeObject<List<mob>>(jsn2);
                    
                    dt = jsn2;
                    start_send_new_messages();
                }
                else
                {
                    newNumbers = null;
                    MessageBox.Show("Fertig : No New Number Found for this message...");
                }

                
            }
            else
            {
                MessageBox.Show("Fertig : No Message Found...");
            }
        }
        void start_send_new_messages()
        {
            string script = string.Format("");
            script += "var dt=" + dt + ";";
            //script += "var activeMsgTxt=\"" + pf.js_unscape(dieMsg.dieText) + "\r\n" + "[" + DateTime.Now.Ticks + "]\r\n" + "\";start_send_new_pms();";
            script += "var activeMsgTxt=\"" + pf.js_unscape(dieMsg.dieText) + "\";start_send_new_pms();";

            CurBrowser.EvaluateScriptAsync(script).ContinueWith(x =>
            {
                var response = x.Result;

                if (response.Success && response.Result != null)
                {
                    var startDate = response.Result;
                }
            });

            //MessageBox.Show("OK");
        }

        private async void jsCmdT_Tick(object sender, EventArgs e)
        {
            jsCmdT.Enabled = false;


            //string script = string.Format("");

            //script += "getCmd();";



           // try { 
            string script = "try{getCmd();}catch (w){}";
            string returnValue = "";

            var task = CurBrowser.EvaluateScriptAsync(script);

            await task.ContinueWith(t =>
            {
                if (!t.IsFaulted)
                {
                    var response = t.Result;

                    if (response.Success && response.Result != null)
                    {
                        returnValue = response.Result.ToString();
                    }
                }
            });

            var ret = (returnValue);
            
            if (!String.IsNullOrWhiteSpace(ret))
            {
                var retAr = pf.vbsplit(ret, "#nd#");
                foreach(var cl in retAr)
                {
                    if (!String.IsNullOrWhiteSpace(cl))
                    {
                        var cltAr = pf.vbsplit(cl, "#np#");
                        foreach (var l in cltAr)
                        {
                            var cmdS = cltAr[0];
                            var val = cltAr[1];
                            if (cmdL.Where(a => (a.name == cmdS) && (a.val == val)).Count() == 0)
                            {
                                cmdL.Add(new cmd(cmdS, val));
                            }

                           
                        }
                    }
                }
            }

            checkCmdl();

            jsCmdT.Enabled = true;
        }
        public class unknown
        {
            public string id = "0";
            public string sid = "0";
            public string ownerTbl = "0";
            public string ownerRec = "0";
            public string isSingle = "1";
            public string isExist = "0";
            public string isNew = "0";
            public string jsn = "";
            public string title = "";
            public string parent = "0";

            public Dictionary<string, string> props = new Dictionary<string, string>();

            public unknown()
            {

            }

        }
        public List<unknown> getUnknownList(string recs)
        {

            var ret = new List<unknown>();

            try
            {

                var jo = JArray.Parse(recs);
                var data = jo;
                foreach (var item in data)
                {
                    var nc = new unknown();
                    JObject inner = item.Value<JObject>();
                    List<string> keys = inner.Properties().Select(p => p.Name).ToList();

                    foreach (string k in keys)
                    {
                        var vl = inner.Properties().Where(a => a.Name == k).First().Value.ToString();

                        switch (k)
                        {
                            case "id":
                                nc.id = vl;
                                break;
                            case "sid":
                                nc.sid = vl;
                                break;
                            case "ownerTbl":
                                nc.ownerTbl = vl;
                                break;
                            case "ownerRec":
                                nc.ownerRec = vl;
                                break;
                            case "isSingle":
                                nc.isSingle = vl;
                                break;
                            case "isExist":
                                nc.isExist = vl;
                                break;
                            case "isNew":
                                nc.isNew = vl;
                                break;

                            default:
                                nc.props.Add(k, vl);
                                break;
                        }

                    }
                    nc.jsn = Newtonsoft.Json.JsonConvert.SerializeObject(nc).ToLower();
                    ret.Add(nc);
                }

            }
            catch (Exception ex)
            {
                //pf.SaveErr(ex, "conv");
                ret = new List<unknown>();
            }

            return ret;
        }
        public void checkCmdl()
        {
            cmdL = cmdL.Distinct().ToList();
            var log = "";
            foreach(var c in cmdL)
            {
                switch (c.name)
                {
                    case "autoGetNumbers":
                        autoGetNumbers = c.val;
                        //MessageBox.Show(autoGetNumbers);
                        break;
                    case "saveMobile":
                        if (true)
                        {
                            var dtar = pf.vbsplit(c.val, "xxbb");
                            //MessageBox.Show
                            var no = dtar[0];
                            var tit = "";
                            try
                            {
                                tit = dtar[1];
                            }catch { }
                            if (no.StartsWith("0"))
                            {
                                no = no.Substring(1, no.Length - 1);
                            }

                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "SelectTable");
                            var query = "";
                            query = "select * from wp_MsgMobilesTbl where dieNumber=#sq#" + no + "#sq#";
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);
                            var havAny = false;
                            try
                            {
                                var hcol = Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                                if (hcol.Count() > 0)
                                {
                                    havAny = true;
                                }
                                else
                                {
                                    havAny = false;
                                }
                            }
                            catch
                            {
                                havAny = false;
                            }

                            if (havAny == false)
                            {
                                var sorc = urList[lastUrlIndx].dieSource;
                                nc = new Dictionary<string, string>();
                                nc.Add("cmd", "RunQuery");
                                query = "";
                                //MessageBox.Show(no);
                                query = "insert into wp_MsgMobilesTbl (sid,dieNumber,haveTelegram,doTest,dieName,dieSource) values(" + sid + ",#sq#" + no + "#sq#,#sq#" + "false" + "#sq#,#sq#false#sq#,#sq#" + pf.js_scape(tit) + "#sq#,#sq#" + sorc + "#sq#)";
                                pf.SaveLog(query);
                                nc.Add("query", query);
                                qret = aph.sendForm(nc);
                            }
                        }
                        break;
                    case "saveURL":
                        if (true)
                        {
                            var hrf = c.val;
                            var sorc = urList[lastUrlIndx].dieSource;

                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "SelectTable");
                            var query = "";
                            query = "select * from wp_msgUrlsTbl where dieUrl=#sq#" + pf.js_scape(hrf) + "#sq#";
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);
                            var havAny = false;
                            try
                            {
                                var hcol = Newtonsoft.Json.JsonConvert.DeserializeObject<List<unknown>>(qret);
                                if (hcol.Count() > 0)
                                {
                                    havAny = true;
                                }
                                else
                                {
                                    havAny = false;
                                }
                            }
                            catch
                            {
                                havAny = false;
                            }

                            if (havAny == false)
                            {
                                nc = new Dictionary<string, string>();
                                nc.Add("cmd", "RunQuery");
                                query = "";
                                query = "insert into wp_msgUrlsTbl (sid,dieUrl,dieSource,dieChecked,dieDate) values(" + sid + ",#sq#" + pf.js_scape(hrf) + "#sq#,#sq#" + sorc + "#sq#,#sq#false#sq#,#sq#" + DateTime.Now.ToString() + "#sq#)";
                                nc.Add("query", query);
                                qret = aph.sendForm(nc);
                            }
                        }
                        break;
                    case "loadNextURL":
                        if (true)
                        {

                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            var query = "";
                            query = "update wp_msgUrlsTbl set dieChecked=#sq#" + "true" + "#sq# where id=" + urList[lastUrlIndx].id;
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);

                            loadNextUrl();

                        }
                        break;
                    case "startProc-SendMessage":
                        if (true)
                        {
                            var mid = c.val;
                            Get_Messages_Data(mid);
                        }
                        break;
                    case "saveNumber":
                        if (true)
                        {
                            var dtAr = pf.vbsplit(c.val, ",");
                            var id = dtAr[0];
                            var havtg = dtAr[1];
                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            var query = "";
                            query = "update wp_MsgMobilesTbl set haveTelegram=#sq#" + havtg + "#sq#,doTest=#sq#" + "true" + "#sq# where id=" + id;
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);
                        }
                        break;
                    case "saveMsg":
                        if (true)
                        {
                            var mobId = c.val;
                            var msgId = dieMsg.id;
                            
                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            var query = "";
                            query = "insert into wp_MsgSentMessages (sid,dieMessage,dieMail,dieMobile,dieDate) values(" + sid + "," + msgId + ",0," + mobId + ",#sq#" + DateTime.Now.ToString() + "#sq#)";
                            nc.Add("query", query);
                            var qret = aph.sendForm(nc);
                        }
                        break;
                    case "sendChar":
                        var sc = c.val;
                        if (sc == "+")
                        {
                            sc = "{+}";
                        }
                        //MessageBox.Show(sc);
                        SendKeys.Send(sc);
                        break;
                    case "sendEnter":
                        SendKeys.Send("{ENTER}");
                        break;
                    case "testAlert":
                        if (true)
                        {
                            //    addCmd("testAlert", "by criss");
                            //log += (c.val) + Environment.NewLine;

                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            var query = "";

                            query = "insert into wp_MsgMobilesTbl (sid,dieNumber,haveTelegram,doTest,dieName,dieSource) values(" + sid + ",#sq#" + DateTime.Now.Ticks + "#sq#,#sq#false#sq#,#sq#false#sq#,#sq#" + c.val + "#sq#,#sq#telegram robot#sq#)";

                            nc.Add("query", query);
                            //var qret = aph.sendForm(nc);
                        }
                        break;
                    case "goNextGPage":
                        jsCmdT.Enabled = false;
                        // MessageBox.Show("0000");
                        //google_search_1();
                        // Inject_ShareCod_google();
                        afterDelayCmd = "Inject_ShareCod_google";
                        delayT.Interval = 10000;
                        delayT.Enabled = true;
                        break;
                }
            }

            cmdL = new List<cmd>();
            if (!String.IsNullOrEmpty(log))
            {
                MessageBox.Show(log+" ...Done");
            }
        }
        public string afterDelayCmd = "";
        private void delayT_Tick(object sender, EventArgs e)
        {
            delayT.Enabled = false;
            switch (afterDelayCmd)
            {
                case "injectdeltajs":
                    injectdeltajs();
                    break;
                case "delta_parse_file":
                    delta_parse_file();
                    break;
                case "delta_2":
                    delta2();
                    break;
                case "delta_read_file_data":
                    delta_read_file_data();
                    break;
                case "delta_check_scroll_cont":
                    delta_check_scroll_cont();
                    break;
                case "delta_scroll_next_page":
                    delta_scroll_next_page();
                    break;
                case "delta_parse_list_2":
                    delta_parse_list_2();
                    break;
                case "delta_parse_list":
                    delta_parse_list();
                    break;
                case "delta_load_datafile":
                    delta_load_datafile();
                    break;
                case "delta_load_nextfile3":
                    delta_load_nextfile3();
                    break;
                case "delta_load_nextfile2":
                    delta_load_nextfile2();
                    break;
                case "delta_load_nextfile":
                    delta_load_nextfile();
                    break;
                case "delta_load_nextlist":
                    delta_load_nextlist();
                    break;
                case "getnextMail":
                    getnextMail();
                    break;
                case "Inject_ShareCod_google":
                    Inject_ShareCod_google();
                    break;

                case "Inject_ShareCod_1":
                    Inject_ShareCod_1();
                    break;
                case "getMobileNumbers":
                    getMobileNumbers();
                    break;
                case "GetNumbersFromUrl_Inject_1":
                    GetNumbersFromUrl_Inject_1();
                    break;
                case "getLinksAndMobiles":
                    getLinksAndMobiles();
                    break;
                case "google_search_1":
                    google_search_1();
                    break;
                case "Hamshahry_klik_estekhdam":
                    Hamshahry_klik_estekhdam();
                    break;
                case "Hamshahry_klik_estekhdam_programer_1":
                    Hamshahry_klik_estekhdam_programer_1();
                    break;
                case "Hamshahry_klik_estekhdam_programer_2":
                    Hamshahry_klik_estekhdam_programer_2();
                    break;
                case "Hamshahry_klik_estekhdam_programer_3":
                    Hamshahry_klik_estekhdam_programer_3();
                    break;
                case "divarScript5":
                    divarScript5();
                    break;
                case "divarScript4":
                    divarScript4();
                    break;
                case "divarScript3":
                    divarScript3();
                    break;
                case "divarScript1":
                    divarScript1();
                    break;
                case "divarScript0":
                    divarScript0();
                    break;
                case "refreshMe":
                    refreshMe();
                    break;
            }
        }

        private void act_Tick(object sender, EventArgs e)
        {
            inremail = false;
            act.Enabled = false;
            return;

            var dts = DateTime.Now.Hour + ":" + DateTime.Now.Minute;
           // MessageBox.Show(dts);
            if (dts == "1:30")
            {
                act.Enabled = false;
               // Hamshahry();
            }
        }
        public Boolean inremail=false;
        private void remailt_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now.Hour == 4)
            {
                if (inremail == false)
                {
                    //Hamshahry();
                }
            }
        }
    }
}

/// <summary>
/// POCO created for holding data per tab
/// </summary>
internal class SharpTab {

	public bool IsOpen;

	public string OrigURL;
	public string CurURL;
	public string Title;

	public string RefererURL;

	public DateTime DateCreated;

	public FATabStripItem Tab;
	public ChromiumWebBrowser Browser;

}

/// <summary>
/// POCO for holding hotkey data
/// </summary>
internal class SharpHotKey {

	public Keys Key;
	public int KeyCode;
	public bool Ctrl;
	public bool Shift;
	public bool Alt;

	public Action Callback;

	public SharpHotKey(Action callback, Keys key, bool ctrl = false, bool shift = false, bool alt = false) {
		Callback = callback;
		Key = key;
		KeyCode = (int)key;
		Ctrl = ctrl;
		Shift = shift;
		Alt = alt;
	}

}